function myFun(){
	var x = document.getElementById('id1');
	if(x.type=="password")
	{
		x.type="text";
	}
	else
	{
		x.type="password";
	}
}

function myFun1(){
	var y = document.getElementById('id2');
	if(y.type=="password")
	{
		y.type="text";
	}
	else
	{
		y.type="password";
	}
}